<p>
    Hey their {{$data}} your are successfully register to Online Varsity.
</p>