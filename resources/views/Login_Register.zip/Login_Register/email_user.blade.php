<p> 
   Enter this code {{$code}} to register in the website.
.</p>